from src.Kidney_Disease_Classification import logger

logger.info("This is a Logger File.")
