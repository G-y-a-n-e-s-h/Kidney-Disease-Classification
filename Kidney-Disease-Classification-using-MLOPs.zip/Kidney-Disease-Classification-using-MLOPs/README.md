# Kidney-Disease-Classification
This project aims to develop a CNN model to classify kidney disease from CT-Scan images. The objective is to assist healthcare professionals in diagnosing kidney diseases by leveraging advanced machine learning techniques. 
